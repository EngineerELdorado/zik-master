<?php 
$type = array('comment','like','frnd');

?>